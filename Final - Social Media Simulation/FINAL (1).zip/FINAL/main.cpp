#include <fstream>
#include <ios>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "Person.hpp"
#include "SocialNetwork.hpp"


// Override the >> operator for std::pair so we can import Edges from connections.txt
std::istream & operator>>( std::istream & stream, std::pair<int, int> & nums )
{
// TODO - IMPLEMENT
}

int main( )
{

  /*
  Part 1 - Setting Things Up
*/

// Task 1 - Complete the operator>> overload for std::pair objects so we can properly import connections.txt below

// Task 2 - Create a SocialNetwork Object

// Task 3 - Import the people.txt file contents into your SocialNetwork object as Nodes.

// Task 4 - Import the connections.txt file contents into your SocialNetwork object as Edges.

// Task 5 - Using std::cout, tell us how many Nodes (people) and how many Edges (connections) there are in the graph.



  // TODO - Construct the graph container



  std::ifstream peopleFile( "people.txt" );
  if( peopleFile.is_open() )
  {
    for( std::string line; std::getline( peopleFile, line ); /**/ )
    {
      // TODO - IMPLEMENT
    }
    peopleFile.close();
  }

  std::ifstream connectionFile( "connections.txt" );
  if( connectionFile.is_open() )
  {
    for( std::string line; std::getline( connectionFile, line ); /**/ )
    {
      // TO DO - IMPLEMENT
    }
  }
  connectionFile.close();
}


/*
  Part 2 - Output some Text
*/

// Task 1 - Output all of the people, sorted ascending by Last Name (A-Z)

// Task 2 - Output all of the people, sorted ascending by age (youngest to oldest)

// Task 3 - Output people whose age is over 33, sorted descending (oldest to youngest)

// Task 4 - Prompt the user to search for a person by inputting a first name and a last name, then attempt to find that person and display their bio.
//          If the person is not found, display a "fname lname was not found" message instead.

// Task 5 - In addition to the bio in Task 4, output the person's list of friends if they are found. 

// Task 6 - Prompt the user to search for 2 people by entering their first and last names
//          Display the degrees of separation between the two people
//          If they are directly connected, display "name1 and name2 are friends!" instead





return 0;
}
